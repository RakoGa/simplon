function calcul   () {
   let articles = document.getElementsByClassName("article");
   let prix = [15,12,14,25,23,27,7,5,6,2,3,3,6,8,3,2,4];
   let total =0;
   let imgHTML = '<img src="img/panier.png" alt="Panier" width="20" height="20">';

   for(i=0; i<articles.length; i++){
    total+= prix[i]*articles[i].value;
   }
   document.getElementById("btnTotal").innerHTML = total + "€ " + imgHTML; 
}



function genererTable() {
   for(let i = 0; i <articles.length; i++){
      // total+= prix[i]*articles[i].value;
      if(document.querySelectorAll('[type="number"]')[i].value > 0) {
         
      }
   
   }
}
